const _ = require("underscore")
const fs = require("fs")

_.templateSettings = {
  evaluate: /\{\{(.+?)\}\}/g,
  interpolate: /\$\{(.+?)\}/g,
}
let quesForType = [
  {
    type: "array",
    data: [
      {
        id: "11",
        level: "中等",
        trans: "盛最多水的容器",
        title: "container-with-most-water",
        times: [true, true],
      },
      {
        id: "15",
        level: "中等",
        trans: "三数之和",
        title: "3sum",
        times: [true],
      },
      {
        id: "1",
        level: "简单",
        trans: "两数之和",
        title: "two-sum",
        times: [true, true],
      },
      {
        id: "283",
        level: "简单",
        trans: "移动零",
        title: "move-zeroes",
        times: [true, true],
      },
    ],
  },
  {
    type: "two-pointers",
    data: [
      {
        id: "125",
        level: "简单",
        trans: "验证回文串",
        title: "valid-palindrome",
        times: [true, true],
      },
    ],
  },
  {
    type: "linked-list",
    data: [
      {
        id: "141",
        level: "简单",
        trans: "环形链表",
        title: "linked-list-cycle",
        times: [true],
      },
      {
        id: "206",
        level: "简单",
        trans: "反转链表",
        title: "reverse-linked-list",
        times: [true],
      },
      {
        id: "24",
        level: "中等",
        trans: "两两交换链表中的节点",
        title: "swap-nodes-in-pairs",
        times: [true, true],
      },
    ],
  },
  {
    type: "dynamic-programming",
    data: [
      {
        id: "70",
        level: "简单",
        trans: "爬楼梯",
        title: "climbing-stairs",
        times: [true],
      },
    ],
  },
]

// [{
//     cnum:'1',
//     ctitle:'1',
//     cpage:'cnum'
// }]
let res = _.template(fs.readFileSync("./lib/readme.tpl").toString())({
  d:'test'
})
console.log(res)
